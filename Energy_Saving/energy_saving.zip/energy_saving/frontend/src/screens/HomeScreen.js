import React, { useState, useEffect } from "react";
import {  Modal} from 'react-native';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  ActivityIndicator,
  SafeAreaView,
} from "react-native";
import { useAuth } from "../context/AuthContext";
import axios from "axios";

const HomeScreen = ({ navigation }) => {
  const { user, logout, refreshToken } = useAuth();
  const [appliances, setAppliances] = useState([
    { id: 1, name: "Refrigerator", powerConsumption: 150, hours: 24 },
    { id: 2, name: "Air Conditioner", powerConsumption: 1500, hours: 8 },
    { id: 3, name: "Television", powerConsumption: 100, hours: 4 },
    { id: 4, name: "Washing Machine", powerConsumption: 500, hours: 1 },
    { id: 5, name: "Microwave", powerConsumption: 1000, hours: 0.5 },
    { id: 6, name: "Light Bulb", powerConsumption: 60, hours: 6 },
    { id: 7, name: "Water Heater", powerConsumption: 2000, hours: 2 },
    { id: 8, name: "Computer", powerConsumption: 300, hours: 5 },
  ]);
  const [energySummary, setEnergySummary] = useState({
    dailyConsumption: 0,
    monthlyConsumption: 0,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const API_URL = "http://192.168.137.19:3000/api"; // Update with your actual API URL

  const [tipModalVisible, setTipModalVisible] = useState(false);
  const [currentTip, setCurrentTip] = useState('');

  const energySavingTips = [
    "Turn off lights when you leave a room to save up to 15% on your energy bill.",
    "Use LED bulbs which use 75% less energy than incandescent lighting.",
    "Unplug electronics when not in use to avoid 'phantom' energy usage.",
    "Set your thermostat 7-10 degrees lower for 8 hours a day to save up to 10% annually.",
    "Wash clothes in cold water to save up to 90% of the energy used in washing.",
    "Use a programmable thermostat to automatically adjust temperatures when you're away.",
    "Clean or replace air filters regularly to improve efficiency by 5-15%.",
    "Air dry clothes instead of using a dryer to save 700+ pounds of carbon dioxide annually.",
    "Use power strips to easily cut power to multiple devices when not in use.",
    "Keep your refrigerator coils clean to improve efficiency by up to 30%."
  ];

  const showRandomTip = () => {
    const randomIndex = Math.floor(Math.random() * energySavingTips.length);
    setCurrentTip(energySavingTips[randomIndex]);
    setTipModalVisible(true);
  };


  useEffect(() => {
    if (user && user.token) {
      fetchUserData();
    } else {
      console.log("No user or token available on component mount");
    }
  }, [user]);

  const fetchUserData = async () => {
    if (!user || !user.token) {
      console.log("No user or token available when fetching data");
      return;
    }

    setIsLoading(true);
    try {
      // Fetch appliances
      const appliancesResponse = await axios.get(
        `${API_URL}/energy/appliances`,
        {
          headers: {
            "x-auth-token": user.token,
          },
        }
      );

      if (
        appliancesResponse.data.appliances &&
        appliancesResponse.data.appliances.length > 0
      ) {
        setAppliances(appliancesResponse.data.appliances);
      }

      // Fetch energy summary
      const summaryResponse = await axios.get(`${API_URL}/energy/summary`, {
        headers: {
          "x-auth-token": user.token,
        },
      });

      if (summaryResponse.data.summary) {
        setEnergySummary(summaryResponse.data.summary);
      }
    } catch (error) {
      console.error(
        "Error fetching user data:",
        error.response?.data || error.message
      );
      if (error.response?.status === 401) {
        Alert.alert(
          "Authentication Error",
          "Your session may have expired. Please log in again.",
          [{ text: "OK", onPress: () => logout() }]
        );
      } else {
        Alert.alert(
          "Error",
          "Failed to load your energy data. Please try again later."
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  const updateApplianceValue = (id, field, value) => {
    const updatedAppliances = appliances.map((appliance) => {
      if (appliance.id === id) {
        return { ...appliance, [field]: value };
      }
      return appliance;
    });
    setAppliances(updatedAppliances);
  };

  const calculateEnergyConsumption = () => {
    let dailyTotal = 0;

    appliances.forEach((appliance) => {
      // kWh = Power (watts) * Hours / 1000
      const dailyEnergy = (appliance.powerConsumption * appliance.hours) / 1000;
      dailyTotal += dailyEnergy;
    });

    const monthlyTotal = dailyTotal * 30;

    setEnergySummary({
      dailyConsumption: dailyTotal,
      monthlyConsumption: monthlyTotal,
    });
  };

  const saveApplianceData = async () => {
    // Verify authentication before proceeding
    if (!user) {
      console.log("No user object available");
      Alert.alert(
        "Authentication Error",
        "You must be logged in to save your data"
      );
      return;
    }

    if (!user.token) {
      console.log("No token available in user object");
      Alert.alert(
        "Authentication Error",
        "Your session may have expired. Please log in again."
      );
      return;
    }

    setIsSaving(true);
    try {
      const headers = {
        "x-auth-token": user.token,
        "Content-Type": "application/json",
      };

      console.log(
        "Sending request with token:",
        user.token.substring(0, 10) + "..."
      );

      const response = await axios.post(
        `${API_URL}/energy/appliances`,
        { appliances },
        { headers }
      );

      if (response.data.success) {
        // Update the energy summary with the returned values
        if (response.data.summary) {
          setEnergySummary(response.data.summary);
        }

        Alert.alert("Success", "Your energy data has been saved");
      } else {
        Alert.alert("Error", response.data.message || "Failed to save data");
      }
    } catch (error) {
      console.error(
        "Error saving appliances:",
        error.response?.data || error.message
      );

      if (error.response?.status === 401) {
        Alert.alert(
          "Authentication Error",
          "Your session has expired. Please log in again.",
          [{ text: "OK", onPress: () => logout() }]
        );
      } else {
        Alert.alert(
          "Error",
          error.response?.data?.message || "Failed to save your energy data"
        );
      }
    } finally {
      setIsSaving(false);
    }
  };

  // Test authentication function
  const testAuthentication = async () => {
    if (!user || !user.token) {
      Alert.alert("Not Logged In", "No authentication token available");
      return;
    }

    try {
      const response = await axios.get(`${API_URL}/auth/verify`, {
        headers: {
          "x-auth-token": user.token,
        },
      });

      Alert.alert(
        "Authentication Status",
        response.data.message || "Authentication is working!"
      );
    } catch (error) {
      console.error("Auth test failed:", error.response?.data || error.message);
      Alert.alert(
        "Authentication Failed",
        error.response?.data?.message || "Token validation failed"
      );
    }
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007bff" />
        <Text style={styles.loadingText}>Loading your energy data...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        style={styles.mainScrollView}
        contentContainerStyle={styles.scrollViewContent}
      >
        <View style={styles.container}>
        <View style={styles.card}>
      <Text style={styles.welcomeText}>Welcome!</Text>
      <Text style={styles.usernameText}>
        {user ? user.username : "User"}
      </Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={styles.profileButton}
          onPress={() => navigation.navigate("Profile")}
        >
          <Text style={styles.buttonText}>View Profile</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.leaderboardButton}
          onPress={() => navigation.navigate("Leaderboard")}
        >
          <Text style={styles.buttonText}>Leaderboard</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.tipButton}
          onPress={showRandomTip}
        >
          <Text style={styles.buttonText}>Tip</Text>
        </TouchableOpacity>
      </View>

      {/* Tip Modal */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={tipModalVisible}
        onRequestClose={() => setTipModalVisible(false)}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.tipTitle}>Energy Saving Tip</Text>
            <Text style={styles.tipText}>{currentTip}</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setTipModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>

          <View style={styles.energyCard}>
            <Text style={styles.energyTitle}>
              Home Energy Consumption Calculator
            </Text>

            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>Your Energy Consumption</Text>
              <View style={styles.summaryRow}>
                <View style={styles.summaryItem}>
                  <Text style={styles.summaryValue}>
                    {energySummary.dailyConsumption.toFixed(2)}
                  </Text>
                  <Text style={styles.summaryLabel}>kWh/day</Text>
                </View>
                <View style={styles.summaryItem}>
                  <Text style={styles.summaryValue}>
                    {energySummary.monthlyConsumption.toFixed(2)}
                  </Text>
                  <Text style={styles.summaryLabel}>kWh/month</Text>
                </View>
              </View>
            </View>

            <ScrollView style={styles.applianceList} nestedScrollEnabled={true}>
              {appliances.map((appliance) => (
                <View key={appliance.id} style={styles.applianceItem}>
                  <Text style={styles.applianceName}>{appliance.name}</Text>

                  <View style={styles.inputRow}>
                    <View style={styles.inputContainer}>
                      <Text style={styles.inputLabel}>Power (Watts)</Text>
                      <TextInput
                        style={styles.input}
                        keyboardType="numeric"
                        value={appliance.powerConsumption.toString()}
                        onChangeText={(value) =>
                          updateApplianceValue(
                            appliance.id,
                            "powerConsumption",
                            parseFloat(value) || 0
                          )
                        }
                      />
                    </View>

                    <View style={styles.inputContainer}>
                      <Text style={styles.inputLabel}>Hours/day</Text>
                      <TextInput
                        style={styles.input}
                        keyboardType="numeric"
                        value={appliance.hours.toString()}
                        onChangeText={(value) =>
                          updateApplianceValue(
                            appliance.id,
                            "hours",
                            parseFloat(value) || 0
                          )
                        }
                      />
                    </View>
                  </View>
                </View>
              ))}
            </ScrollView>

            <View style={styles.actionButtons}>
              <TouchableOpacity
                style={[
                  styles.calcButton,
                  (isLoading || isSaving) && styles.disabledButton,
                ]}
                onPress={calculateEnergyConsumption}
                disabled={isLoading || isSaving}
              >
                <Text style={styles.buttonText}>Calculate</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.saveButton,
                  (isLoading || isSaving) && styles.disabledButton,
                ]}
                onPress={saveApplianceData}
                disabled={isLoading || isSaving}
              >
                {isSaving ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Save</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  mainScrollView: {
    flex: 1,
  },
  scrollViewContent: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f5f5f5",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#666",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  welcomeText: {
    fontSize: 24,
    marginBottom: 10,
    color: "#333",
  },
  usernameText: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#007bff",
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  profileButton: {
    backgroundColor: "#007bff",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    flex: 1,
    marginRight: 10,
  },

  leaderboardButton: {
    backgroundColor: "#007bff",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    flex: 1,
    marginRight: 10,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },

  testButton: {
    backgroundColor: "#e2e6ea",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 10,
  },
  testButtonText: {
    color: "#007bff",
    fontSize: 14,
  },
  energyCard: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    flex: 1,
  },
  energyTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 15,
    color: "#333",
    textAlign: "center",
  },
  summaryCard: {
    backgroundColor: "#e8f4fd",
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#0056b3",
    marginBottom: 10,
    textAlign: "center",
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  summaryItem: {
    alignItems: "center",
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#007bff",
  },
  summaryLabel: {
    fontSize: 14,
    color: "#555",
    marginTop: 5,
  },
  applianceList: {
    maxHeight: 250,
  },
  applianceItem: {
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
    paddingVertical: 10,
  },
  applianceName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  inputRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  inputContainer: {
    flex: 1,
    marginHorizontal: 5,
  },
  inputLabel: {
    fontSize: 12,
    color: "#666",
    marginBottom: 3,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 5,
    padding: 8,
    backgroundColor: "#f9f9f9",
  },
  actionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 15,
  },
  calcButton: {
    backgroundColor: "#28a745",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    marginRight: 10,
  },
  saveButton: {
    backgroundColor: "#007bff",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },
  disabledButton: {
    opacity: 0.7,
  },

  tipButton: {
    backgroundColor: '#FF9800',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    marginHorizontal: 5,
    marginBottom: 10,
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    width: '80%',
  },
  tipTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#FF9800',
  },
  tipText: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 22,
  },
  closeButton: {
    backgroundColor: '#FF9800',
    borderRadius: 5,
    padding: 10,
    elevation: 2,
    marginTop: 5,
  },
  closeButtonText: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default HomeScreen;

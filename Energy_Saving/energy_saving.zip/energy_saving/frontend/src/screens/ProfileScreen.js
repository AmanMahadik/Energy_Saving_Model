import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const ProfileScreen = () => {
  const { user, logout } = useAuth();
  const [energyData, setEnergyData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const API_URL = 'http://192.168.137.19:3000/api'; // Make sure this matches your HomeScreen

  // Format date for better display
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  useEffect(() => {
    fetchEnergyData();
  }, []);

  const fetchEnergyData = async () => {
    if (!user || !user.token) return;
    
    setIsLoading(true);
    try {
      // Fetch energy summary
      const summaryResponse = await axios.get(`${API_URL}/energy/summary`, {
        headers: {
          'x-auth-token': user.token
        }
      });
      
      if (summaryResponse.data.summary) {
        setEnergyData(summaryResponse.data.summary);
      }
    } catch (error) {
      console.error('Error fetching energy data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.profileImageContainer}>
          <Text style={styles.profileInitial}>{user?.username?.charAt(0).toUpperCase() || 'U'}</Text>
        </View>
        <Text style={styles.usernameText}>{user?.username || 'User'}</Text>
      </View>
      
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Account Information</Text>
        
        <View style={styles.fieldContainer}>
          <Text style={styles.fieldLabel}>Username</Text>
          <Text style={styles.fieldValue}>{user?.username || 'N/A'}</Text>
        </View>
        
        <View style={styles.fieldContainer}>
          <Text style={styles.fieldLabel}>Email</Text>
          <Text style={styles.fieldValue}>{user?.email || 'N/A'}</Text>
        </View>
      </View>
      
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Energy Consumption</Text>
        
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="small" color="#007bff" />
            <Text style={styles.loadingText}>Loading energy data...</Text>
          </View>
        ) : energyData ? (
          <>
            <View style={styles.energyStatsContainer}>
              <View style={styles.energyStat}>
                <Text style={styles.energyValue}>{energyData.dailyConsumption.toFixed(2)}</Text>
                <Text style={styles.energyLabel}>kWh/day</Text>
              </View>
              
              <View style={styles.verticalDivider} />
              
              <View style={styles.energyStat}>
                <Text style={styles.energyValue}>{energyData.monthlyConsumption.toFixed(2)}</Text>
                <Text style={styles.energyLabel}>kWh/month</Text>
              </View>
            </View>
            
            <View style={styles.estimateContainer}>
  <Text style={styles.estimateLabel}>Estimated Monthly Cost:</Text>
  <Text style={styles.estimateValue}>
    ₹{(energyData.monthlyConsumption * 0.12 * 83).toFixed(2)}
  </Text>
  <Text style={styles.estimateNote}>Based on average rate of ₹9.96/kWh (converted from $0.12/kWh)</Text>
</View>

            
            <TouchableOpacity
              style={styles.refreshButton}
              onPress={fetchEnergyData}
            >
              <Text style={styles.refreshButtonText}>Refresh Data</Text>
            </TouchableOpacity>
          </>
        ) : (
          <View style={styles.noDataContainer}>
            <Text style={styles.noDataText}>
              No energy data available. Calculate your consumption on the home screen.
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.actionsContainer}>
        <TouchableOpacity
          style={styles.logoutButton}
          onPress={logout}
        >
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#007bff',
    padding: 30,
    alignItems: 'center',
  },
  profileImageContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  profileInitial: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#007bff',
  },
  usernameText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    margin: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  fieldContainer: {
    marginBottom: 15,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  fieldLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  fieldValue: {
    fontSize: 16,
    color: '#333',
  },
  loadingContainer: {
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  },
  energyStatsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#e8f4fd',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
  },
  energyStat: {
    alignItems: 'center',
    flex: 1,
  },
  energyValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#007bff',
  },
  energyLabel: {
    fontSize: 14,
    color: '#555',
    marginTop: 5,
  },
  verticalDivider: {
    height: 40,
    width: 1,
    backgroundColor: '#cce5ff',
  },
  estimateContainer: {
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
  },
  estimateLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  estimateValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#28a745',
    marginBottom: 5,
  },
  estimateNote: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
  },
  noDataContainer: {
    padding: 20,
    alignItems: 'center',
  },
  noDataText: {
    textAlign: 'center',
    color: '#666',
  },
  refreshButton: {
    backgroundColor: '#e8f4fd',
    padding: 12,
    borderRadius: 5,
    alignItems: 'center',
  },
  refreshButtonText: {
    color: '#007bff',
    fontWeight: 'bold',
  },
  actionsContainer: {
    margin: 15,
  },
  logoutButton: {
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  logoutText: {
    color: '#dc3545',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, Alert, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Ionicons } from '@expo/vector-icons';

const API_URL = 'http://192.168.137.19:3000';

const LeaderboardScreen = () => {
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);
  const [averageConsumption, setAverageConsumption] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (!userData) {
        setError('You need to login to view the leaderboard');
        setLoading(false);
        return;
      }
      
      const parsedUser = JSON.parse(userData);
      setUser(parsedUser);
      
      // Now that we have the user data, fetch the leaderboard
      fetchLeaderboardData(parsedUser);
    } catch (error) {
      console.error('Error retrieving user data:', error);
      setError('Failed to authenticate. Please log in again.');
      setLoading(false);
    }
  };

  const fetchLeaderboardData = async (userData) => {
    if (!userData || !userData.token) {
      setError('Authentication error. Please log in again.');
      setLoading(false);
      return;
    }

    try {
      const headers = {
        'x-auth-token': userData.token,
        'Content-Type': 'application/json'
      };
      
      console.log('Sending request with token:', userData.token.substring(0, 10) + '...');
      
      const response = await axios.get(`${API_URL}/api/energy/leaderboard`, { headers });
      
      setLeaderboardData(response.data.leaderboard);
      setAverageConsumption(response.data.averageConsumption);
      setLoading(false);
      setRefreshing(false);
    } catch (error) {
      console.error('Error fetching leaderboard data:', error.response?.data || error.message);
      
      if (error.response?.status === 401) {
        setError('Your session has expired. Please log in again.');
      } else {
        setError('Failed to load leaderboard. Please try again later.');
      }
      
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchUserData();
  };

  const getBadgeIcon = (badge) => {
    switch(badge) {
      case 'Energy Champion':
        return <Ionicons name="trophy" size={22} color="#FFD700" />;
      case 'Energy Master':
        return <Ionicons name="medal" size={22} color="#C0C0C0" />;
      case 'Energy Expert':
        return <Ionicons name="medal" size={22} color="#CD7F32" />;
      case 'Energy Saver':
        return <Ionicons name="leaf" size={22} color="#4CAF50" />;
      default:
        return <Ionicons name="person" size={22} color="#757575" />;
    }
  };

  const renderLeaderboardItem = ({ item, index }) => {
    // Check if this is the current user
    const isCurrentUser = user && item.username === user.username;
    
    return (
      <View style={[
        styles.tableRow, 
        index % 2 === 0 ? styles.evenRow : styles.oddRow,
        index === 0 ? styles.topRankedRow : null,
        isCurrentUser ? styles.currentUserRow : null
      ]}>
        <Text style={[styles.rankCell, index === 0 ? styles.topRankedText : null]}>{index + 1}</Text>
        <View style={styles.userCell}>
          <Text style={[styles.usernameText, index === 0 ? styles.topRankedText : null, isCurrentUser ? styles.currentUserText : null]}>
            {item.username} {isCurrentUser ? '(You)' : ''}
          </Text>
          <View style={styles.badgeContainer}>
            {getBadgeIcon(item.badge)}
            <Text style={styles.badgeText}>{item.badge}</Text>
          </View>
        </View>
        <View style={styles.statsCell}>
          <Text style={[styles.savingsText, index === 0 ? styles.topRankedText : null]}>
            {item.savingsPercentage}% saved
          </Text>
          <Text style={styles.savedEnergyText}>
            {item.energySaved.toFixed(2)} kWh
          </Text>
        </View>
      </View>
    );
  };

  const renderTableHeader = () => (
    <View style={[styles.tableRow, styles.tableHeader]}>
      <Text style={[styles.rankCell, styles.headerText]}>Rank</Text>
      <Text style={[styles.userHeaderCell, styles.headerText]}>Champion</Text>
      <Text style={[styles.statsHeaderCell, styles.headerText]}>Energy Saved</Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={styles.loadingText}>Loading energy champions data...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerSection}>
        <Text style={styles.title}>Energy Champions</Text>
        <TouchableOpacity style={styles.refreshButton} onPress={onRefresh}>
          <Ionicons name="refresh" size={24} color="#4CAF50" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.infoCard}>
        <Text style={styles.infoText}>
          Save energy to climb the leaderboard! The average energy consumption is {averageConsumption.toFixed(2)} kWh per month.
        </Text>
      </View>
      
      {leaderboardData.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="leaf" size={64} color="#4CAF50" />
          <Text style={styles.emptyText}>Be the first energy champion!</Text>
          <Text style={styles.emptySubText}>Add your appliances to start tracking energy savings</Text>
        </View>
      ) : (
        <View style={styles.tableContainer}>
          {renderTableHeader()}
          <FlatList
            data={leaderboardData}
            renderItem={renderLeaderboardItem}
            keyExtractor={(item, index) => `user-${index}`}
            refreshing={refreshing}
            onRefresh={onRefresh}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F5F5F5',
  },
  headerSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  refreshButton: {
    padding: 8,
  },
  infoCard: {
    backgroundColor: '#E8F5E9',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  infoText: {
    color: '#2E7D32',
    fontSize: 14,
  },
  tableContainer: {
    flex: 1,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    backgroundColor: '#FFF',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    alignItems: 'center',
  },
  tableHeader: {
    backgroundColor: '#4CAF50',
    borderBottomWidth: 2,
    borderBottomColor: '#2E7D32',
  },
  headerText: {
    fontWeight: 'bold',
    color: 'white',
  },
  rankCell: {
    width: 40,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  userCell: {
    flex: 3,
    justifyContent: 'center',
  },
  userHeaderCell: {
    flex: 3,
  },
  statsCell: {
    flex: 2,
    alignItems: 'flex-end',
  },
  statsHeaderCell: {
    flex: 2,
    textAlign: 'right',
  },
  usernameText: {
    fontWeight: '500',
    fontSize: 16,
  },
  badgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  badgeText: {
    fontSize: 12,
    color: '#757575',
    marginLeft: 4,
  },
  savingsText: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  savedEnergyText: {
    fontSize: 12,
    color: '#757575',
  },
  evenRow: {
    backgroundColor: '#F9FFF9',
  },
  oddRow: {
    backgroundColor: '#FFFFFF',
  },
  topRankedRow: {
    backgroundColor: '#E8F5E9',
  },
  currentUserRow: {
    backgroundColor: '#E3F2FD',
    borderLeftWidth: 3,
    borderLeftColor: '#2196F3',
  },
  topRankedText: {
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  currentUserText: {
    fontWeight: 'bold',
    color: '#1976D2',
  },
  loadingText: {
    marginTop: 16,
    textAlign: 'center',
    color: '#757575',
  },
  errorText: {
    color: '#D32F2F',
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 40,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginTop: 16,
  },
  emptySubText: {
    fontSize: 14,
    color: '#757575',
    marginTop: 8,
    textAlign: 'center',
  },
});

export default LeaderboardScreen;